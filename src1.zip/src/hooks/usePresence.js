import { useEffect, useRef } from 'react';
import { supabase } from '../lib/supabaseClient';

/**
 * usePresence — keeps is_online and last_seen accurate for the current user.
 *
 * Strategy:
 *   1. Mark online immediately on mount
 *   2. Send a heartbeat every 60s to keep last_seen fresh
 *   3. Mark offline on cleanup (tab close, sign out, component unmount)
 *   4. Use Page Visibility API as a backup — marks offline when tab is
 *      hidden and online again when it comes back (works on mobile too)
 */
export function usePresence(userId) {
  const intervalRef = useRef(null);

  useEffect(() => {
    if (!userId) return;

    // ── Helpers ────────────────────────────────────────────────────────
    const markOnline = () =>
      supabase
        .from('player_profiles')
        .update({ is_online: true, last_seen: new Date().toISOString() })
        .eq('id', userId);

    const markOffline = () =>
      supabase
        .from('player_profiles')
        .update({ is_online: false, last_seen: new Date().toISOString() })
        .eq('id', userId);

    // ── 1. Mark online immediately ─────────────────────────────────────
    markOnline();

    // ── 2. Heartbeat every 60 seconds ─────────────────────────────────
    // This keeps last_seen fresh so "Last seen Xm ago" stays accurate
    intervalRef.current = setInterval(() => {
      if (document.visibilityState === 'visible') {
        markOnline();
      }
    }, 60 * 1000);

    // ── 3. Page Visibility API ─────────────────────────────────────────
    // Fires reliably on mobile when user switches apps or locks screen
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        markOnline();
      } else {
        markOffline();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // ── 4. beforeunload as extra safety net (desktop) ──────────────────
    window.addEventListener('beforeunload', markOffline);

    // ── Cleanup ────────────────────────────────────────────────────────
    return () => {
      clearInterval(intervalRef.current);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', markOffline);
      markOffline();
    };
  }, [userId]);
}
